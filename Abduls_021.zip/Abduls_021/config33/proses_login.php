<?php
session_start();
include("koneksi.php");

$username = $_POST['username'];
$password = md5($_POST['password']); // Hash password menggunakan MD5

// Query untuk mengambil data user berdasarkan username
$login = mysqli_query($config, "SELECT * FROM user WHERE username='$username' AND password='$password'");
$cek = mysqli_num_rows($login);

if ($cek > 0) {
    $data = mysqli_fetch_assoc($login);

    // Cek role user dan redirect sesuai dengan role
    if ($data['role'] == "Admin") {
        $_SESSION['username'] = $username;
        $_SESSION['role'] = "Admin";
        header('location:../Admin/index.php');
    } else if ($data['role'] == "Petugas") {
        $_SESSION['username'] = $username;
        $_SESSION['role'] = "Petugas";
        header('location:../Petugas/index.php');
    }
} else {
    // Jika username atau password salah
    echo "<script type='text/javascript'>alert('Username Atau Password Anda Salah !!!'); history.back(self);</script>";
}
?>
