<!-- <?php
session_start();
if (isset($_SESSION['username'])) {
	unset($_SESSION['username']);
}
header("location:../index.php");

session_destroy();
?> -->

<?php
session_start();
session_unset();
session_destroy();
session_regenerate_id(delete_old_session:true);
header(header : "location:../index.php");
exit();
?>

