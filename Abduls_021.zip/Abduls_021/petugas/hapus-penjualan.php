<?php
include("../config/koneksi.php");
$hasil = $_REQUEST['id_penjualan'];
$perintah = mysqli_query($config, "delete from penjualan where id_penjualan='$hasil'");
if ($perintah) {
    echo "<script>alert('Data penjualan Berhasil di Hapus!');
    location.href=('tampil-penjualan.php');
    </script>;
";
} else {
    echo mysqli_error($config);
    //echo "<script>alert('Data penjualan Gagal Di Hapus'); history.back(self)</script>;";
}
?>