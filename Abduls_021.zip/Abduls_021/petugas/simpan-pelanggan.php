<?php
include("../config/koneksi.php");
$id_pelanggan = $_POST['id_pelanggan'];
$nama_pelanggan= $_POST['nama_pelanggan'];
$alamat = $_POST['alamat'];
$no_hp = $_POST['no_hp'];

$query = mysqli_query($config, "insert into pelanggan (id_pelanggan, nama_pelanggan, alamat, no_hp)
values ('$id_pelanggan','$nama_pelanggan','$alamat','$no_hp')");
if ($query) {
    echo "<script>alert('Data Barang Tersimpan !!!');location.href=('tampil-pelanggan.php');</script>";
} else {
    echo mysqli_error($config);
    //echo "<script type='text/javascript'>alert('Data Barang Gagal Tersimpan !!!'); history.back(self);</script>'";   
} 
// cek apakah id barang sudah ada
$query= mysqli_query($config,"SELECT * FROM pelanggan WHERE id_pelanggan = '$id_pelanggan'");
if (mysqli_num_rows($query)>0){
    //jika id sudah digunakan, tampilan notifikasi
    echo "<script>
    alert('id pelanggan sudah digunakan.silahkan gunakan id lain');history.back(self);</script>";
    exit();
}

// cek panjang nomor hp
if (strlen($no_hp) > 10 ) {
    echo " nomor hp tidak boleh dari 10 digit";
    exit();
}

?>
