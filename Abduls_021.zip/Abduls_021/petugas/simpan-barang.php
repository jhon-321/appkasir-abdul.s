<?php
include("../config/koneksi.php");
$id_barang = $_POST['id_barang'];
$nama_barang = $_POST['nama_barang'];
$harga = $_POST['harga'];
$stok = $_POST['stok'];

$query = mysqli_query($config, "insert into barang (id_barang, nama_barang, harga, stok)
values ('$id_barang','$nama_barang','$harga','$stok')");
if ($query) {
    echo "<script>alert('Data Barang Tersimpan !!!');location.href=('tampil-barang.php');</script>";
} else {
    echo mysqli_error($config);
    //echo "<script type='text/javascript'>alert('Data Barang Gagal Tersimpan !!!'); history.back(self);</script>'";   
} 

// cek apakah id barang sudah ada
$query= mysqli_query($config,"SELECT * FROM barang WHERE id_barang = '$id_barang'");
if (mysqli_num_rows($query)>0){
    //jika id sudah digunakan, tampilan notifikasi
    echo "<script>
    alert('id barang sudah digunakan.silahkan gunakan id lain');history.back(self);</script>";
    exit();
}

?>
