<?php
session_start();
include("koneksi.php");
$username = $_POST['username'];
$password = md5($_POST['password']);

// Query untuk mengambil data user berdasarkan username
$login = mysqli_query($config, "SELECT * FROM user WHERE username='$username' AND password='$password'");
$cek = mysqli_num_rows($login);

if ($cek > 0) {
    $data = mysqli_fetch_assoc($login);

    if ($data['role'] == "Admin") {
        $_SESSION['username'] = $username;
        $_SESSION['role'] = "Admin";
        header('Location:../Admin/index.php');
    } else if ($data['role'] == "petugas") {
        $_SESSION['username'] = $username;
        $_SESSION['role'] = "petugas";
        header('Location:../petugas/index.php');
    }
} else {
    echo "<script type='text/javascript'>alert('Username Atau Password Anda Salah !!!'); history.back(self);</script>";
}
?>
