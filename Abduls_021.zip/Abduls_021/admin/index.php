<?php 
session_start();
if (!isset ($_SESSION['username'])){
  header(header:"location:../index.php");
  exit();
}
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" >

    <title>app kasir</title>
    
  </head>
  <body>
    
    <nav class="navbar navbar-expand-lg navbar-light bg-primary">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">App Kasir</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index.php">Home</a>
        </li>
           <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Barang
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="tambah-barang.php">Tambah Barang</a></li>
            <li><a class="dropdown-item" href="tampil-barang.php">Tampil Barang</a></li>
            <li><a class="dropdown-item" href="Cetak-barang.php" target="blank">Cetak Barang</a></li>
          </ul>
        </li>
         <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Pelanggan
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="tambah-pelanggan.php">Tambah Pelanggan</a></li>
            <li><a class="dropdown-item" href="tampil-pelanggan.php">Tampil Pelanggan</a></li>
            <li><a class="dropdown-item" href="cetak-pelanggan.php"target="blank">Cetak Pelanggan</a></li>
          </ul>
        </li>
         <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            User
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="tambah-user.php">Tambah User</a></li>
            <li><a class="dropdown-item" href="tampil-user.php">Tampil User</a></li>
            <li><a class="dropdown-item" href="cetak-user.php"target="blank">Cetak User</a></li>
          </ul>
        </li>
         <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="../config/logout.php " onclick="return confirm('Apakah Anda Yakin Ingin Logout ???')">Logout</a>
        </li>
      </ul>
    </div>
  </div>
</nav>




<div class="container-fluid">
  <h3>Home</h3>
  <h4>Selamat Datang Administarasi</h4>
</div>

<div class="row">

<div class="col">
    <div class="card" style="width: 18rem;">
        <div class="card-body bg-info">
            <h5 class="card-title text-white">Jumlah Barang</h5>
            <div class="display-4 text-white">
                <?php
                include("../config/koneksi.php");
                $sql = mysqli_query($config, "select * from barang");
                $jml_data = mysqli_num_rows($sql);
                if ($jml_data > 0) {
                    echo "<b>$jml_data</b>";
                }
                ?>
       

    </div>
    <a href= "tampil-barang.php" class= "card-text text-white"><p class="card-text">Lihat Detail</p>
    </a>
  </div>
</div>
    </div>

    <div class="col">
    <div class="card" style="width: 18rem;">
        <div class="card-body bg-warning">
            <h5 class="card-title text-white">Jumlah pelanggan</h5>
            <div class="display-4 text-white">
                <?php
                include("../config/koneksi.php");
                $sql = mysqli_query($config, "select * from pelanggan");
                $jml_data = mysqli_num_rows($sql);
                if ($jml_data > 0) {
                    echo "<b>$jml_data</b>";
                }
                ?>
     

    </div>
    <a href= "tampil-pelanggan.php" class= "card-text text-white"><p class="card-text">Lihat Detail</p>
    </a>
  </div>
</div>
    </div>

    <div class="col">
    <div class="card" style="width: 18rem;">
        <div class="card-body bg-danger">
            <h5 class="card-title text-white">Jumlah user</h5>
            <div class="display-4 text-white">
                <?php
                include("../config/koneksi.php");
                $sql = mysqli_query($config, "select * from user");
                $jml_data = mysqli_num_rows($sql);
                if ($jml_data > 0) {
                    echo "<b>$jml_data</b>";
                }
                ?>
            

   
  
  </div>
  <a href= "tampil-user.php" class= "card-text text-white"><p class="card-text">Lihat Detail</p>
    </a>
</div>
    </div>
  </div>
</div>
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="../assets/js/bootstrap.bundle.min.js"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    -->
  </body>
</html>
