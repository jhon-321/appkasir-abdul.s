<?php
include("../config/koneksi.php");
$hasil = $_REQUEST['id_barang'];
$perintah = mysqli_query($config, "delete from barang where id_barang='$hasil'");
if ($perintah) {
    echo "<script>alert('Data Barang Berhasil di Hapus!');
    location.href=('tampil-barang.php');
    </script>;
";
} else {
    echo mysqli_error($config);
    //echo "<script>alert('Data Barang Gagal Di Hapus'); history.back(self)</script>;";
}
?>