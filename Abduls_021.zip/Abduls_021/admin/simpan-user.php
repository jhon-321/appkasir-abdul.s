<?php
include("../config/koneksi.php");
$id_user = $_POST['id_user'];
$nama= $_POST['nama'];
$username = $_POST['username'];
$password = $_POST['password'];
$role = $_POST['role'];

$query = mysqli_query($config, "insert into user (id_user, nama, username, password, role)
values ('$id_user','$nama','$username','$password','$role' )");
if ($query) {
    echo "<script>alert('Data user Tersimpan !!!');location.href=('tampil-user.php');</script>";
} else {
    echo mysqli_error($config);
    //echo "<script type='text/javascript'>alert('Data user Gagal Tersimpan !!!'); history.back(self);</script>'";   
} 
// cek apakah id barang sudah ada
$query= mysqli_query($config,"SELECT * FROM user WHERE id_user = '$id_user'");
if (mysqli_num_rows($query)>0){
    //jika id sudah digunakan, tampilan notifikasi
    echo "<script>
    alert('id user sudah digunakan.silahkan gunakan id yang lain');history.back(self);</script>";
    exit();
}

?>
