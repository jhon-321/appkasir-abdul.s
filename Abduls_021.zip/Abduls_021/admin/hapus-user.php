<?php
include("../config/koneksi.php");
$hasil = $_REQUEST['id_user'];
$perintah = mysqli_query($config, "delete from user where id_user='$hasil'");
if ($perintah) {
    echo "<script>alert('Data user Berhasil di Hapus!');
    location.href=('tampil-user.php');
    </script>;
";
} else {
    echo mysqli_error($config);
    //echo "<script>alert('Data user Gagal Di Hapus'); history.back(self)</script>;";
}
?>