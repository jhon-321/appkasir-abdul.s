<?php
include("../config/koneksi.php");
$hasil = $_REQUEST['id_pelanggan'];
$perintah = mysqli_query($config, "delete from pelanggan where id_pelanggan='$hasil'");
if ($perintah) {
    echo "<script>alert('Data pelanggan Berhasil di Hapus!');
    location.href=('tampil-pelanggan.php');
    </script>;
";
} else {
    echo mysqli_error($config);
    //echo "<script>alert('Data pelanggan Gagal Di Hapus'); history.back(self)</script>;";
}
?>