


<!doctype html>
<html lang="e">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Aplikasi Kasir</title>
    <script language="javascript1.2">
        function printpage(){
            window.print();
        }
    </script>
</head>

<body onload="printpage()">
     <h2>
        <center>Data user</center>
    </h2>
    <table border="1" align="center">

        <tr>
            <th>NO</th>
            <th>ID user</th>
            <th>Nama user</th>
            <th>username</th>
            <th>password</th>
            <th>Role</th>
      </tr>
     <?php
     include("../config/koneksi.php");
     $i = 1;
     $query = mysqli_query($config, "select * from user");
     while ($data = mysqli_fetch_array($query)) {
        echo "<tr>
                <td>$i</td>
                <td>$data[id_user]</td>
                <td>$data[nama]</td>
                <td>$data[username]</td>
                <td>$data[password]</td>
                <td>$data[role]</td>
            </tr>";
        $i = $i + 1;
     }
     ?>
</body>

</html>