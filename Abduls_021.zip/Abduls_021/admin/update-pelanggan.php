<?php
include("../config/koneksi.php");
$id_pelanggan = $_POST['id_pelanggan'];
$nama_pelanggan = $_POST['nama_pelanggan'];
$alamat = $_POST['alamat'];
$no_hp = $_POST['no_hp'];

$query = mysqli_query($config, "update pelanggan set id_pelanggan='$id_pelanggan', nama_pelanggan='$nama_pelanggan', alamat='$alamat', no_hp='$no_hp' where id_pelanggan='$id_pelanggan'");

if ($query) {
    echo "<script>alert('Data pelanggan Di Update !!!');location.href=('tampil-pelanggan.php');</script>";
} else {
    echo "<script type='text/javascript'>alert('Data pelanggan Gagal Di Update !!!'); history.back(self);</script>'";
}
?>
